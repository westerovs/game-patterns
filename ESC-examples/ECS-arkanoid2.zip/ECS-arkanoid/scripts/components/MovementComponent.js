export default class MovementComponent {
  constructor(dx, dy, velocity) {
    this.dx = dx;
    this.dy = dy;
    this.velocity = velocity;
  }
}
