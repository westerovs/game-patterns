export default class RenderComponent {
  constructor(sprite, width, height) {
    this.sprite = sprite;
    this.width = width;
    this.height = height;
  }
}
