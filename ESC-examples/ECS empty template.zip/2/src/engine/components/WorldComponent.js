export default class WorldComponent {
  constructor() {

  }

}
