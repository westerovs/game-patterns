export default class RenderComponent {
  constructor() {

  }

}
