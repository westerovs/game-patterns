export default class BaseComponent {
  constructor() {

  }

}
