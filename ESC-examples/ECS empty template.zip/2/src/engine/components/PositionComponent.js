export default class PositionComponent {
  constructor() {

  }

}
