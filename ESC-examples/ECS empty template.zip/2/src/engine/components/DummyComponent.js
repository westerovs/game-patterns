export default class DummyComponent {
  constructor() {

  }

}
