export default class CenitalView2DMovementSystem {
  constructor() {

  }

}
