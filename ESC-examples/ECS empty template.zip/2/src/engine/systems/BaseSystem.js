export default class BaseSystem {
  constructor() {

  }

}
