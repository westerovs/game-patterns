export default class RenderSystem {
  constructor() {

  }

}
