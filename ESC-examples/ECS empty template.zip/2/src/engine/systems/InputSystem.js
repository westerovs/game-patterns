export default class InputSystem {
  constructor() {

  }

}
