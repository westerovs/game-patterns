export default class EntityManager {
  constructor() {

  }

}
