export default class ComponentManager {
  constructor() {

  }

}
