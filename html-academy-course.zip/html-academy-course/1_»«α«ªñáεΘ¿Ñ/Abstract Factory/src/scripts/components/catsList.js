function catsList() {
  return `<ul class="list"></ul>`
}

export default catsList;
