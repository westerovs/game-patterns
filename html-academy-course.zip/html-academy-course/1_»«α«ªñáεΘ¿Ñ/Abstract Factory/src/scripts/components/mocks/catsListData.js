const catsListData = [
  {
    name: "Кот Базилио",
    about:
      "Прошлые хозяева отказались от&nbsp;него, и&nbsp;долгое время ему пришлось быть на&nbsp;передержке, привыкая к&nbsp;новой жизни.",
    image: 'https://i.ibb.co/pWkHFrj/Rectangle-4-1.png" alt="Rectangle-4-1',
    type: null,
  },
  {
    name: "Кот Лаки",
    about:
      "Крайне спокойный, ласковый малыш, который медленно, но&nbsp;уверенно перестаёт быть робким скромнягой.",
    image: "https://i.ibb.co/Cmgp1tP/Rectangle-4.png",
    type: "special",
  },
  {
    name: "Кошка Сью",
    about:
      "Эта юная красавица очень общительная и&nbsp;ласковая уже с&nbsp;первого дня, как приехала в&nbsp;кафе.",
    image: "https://i.ibb.co/27Mdx7k/Rectangle-4-2.png",
    type: null,
  },
]

export {
  catsListData,
}
